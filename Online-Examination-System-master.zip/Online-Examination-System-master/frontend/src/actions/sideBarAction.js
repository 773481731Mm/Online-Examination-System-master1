import { TOOGLE_NAVIGATION } from './types';



export const toogleNav = ()=> dispatch =>{
    dispatch({
       type : TOOGLE_NAVIGATION
    })
}
